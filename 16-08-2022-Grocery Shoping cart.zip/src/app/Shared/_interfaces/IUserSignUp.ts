export interface UserSignUp {
  email: string;
  password: string;
  // returnSecureToken: boolean;
}
