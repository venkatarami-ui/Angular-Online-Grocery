export interface UserRole {
  email: string;
  name: string;
  role: string;
}
